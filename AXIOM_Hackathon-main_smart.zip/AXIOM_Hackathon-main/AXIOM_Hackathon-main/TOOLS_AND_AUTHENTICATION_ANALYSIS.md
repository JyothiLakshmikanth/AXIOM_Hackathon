# AXIOM Tools & Authentication Analysis

## 1. Tools Architecture Overview

### Current Tool System

```
┌──────────────────────────────────────────────────────────────────────┐
│                      AXIOM TOOLS ARCHITECTURE                        │
└──────────────────────────────────────────────────────────────────────┘

Tools are organized by domain:

agents/tools/
├── firestore_tools.py          (Runtime memory, session state, evidence cache)
├── bigquery_tools.py           (Structured project facts, analytics)
├── neo4j_tools.py              (Knowledge graph queries)
├── git_tools.py                (Git commit analysis, patches)
└── specialized/
    ├── defect_tools.py         (Defect-specific BigQuery queries)
    ├── requirement_tools.py     (Requirement Neo4j queries)
    ├── test_tools.py           (Test case management)
    └── resource_tools.py       (Team capacity queries)
```

---

## 2. Firestore Tools — Runtime Memory

### Current Implementation

```python
def firestore_cache_evidence(entity_id: str, evidence_envelope: Dict[str, Any]) -> bool:
    """Saves a verified EvidenceEnvelope to Firestore."""
    client = get_firestore_client()
    if client:
        try:
            # LIVE FIRESTORE: collections/evidence_cache/documents
            client.collection("evidence_cache").document(entity_id).set(evidence_envelope)
            return True
        except Exception as e:
            logger.warning(f"Error saving to live Firestore: {e}")
    
    # FALLBACK: Local in-memory store
    _LOCAL_FIRESTORE_STORE["evidence_cache"][entity_id] = evidence_envelope
    return True
```

### Features:

✅ **Live Firestore Integration**
- Uses Google Cloud Firestore if credentials available
- Automatic fallback to local in-memory store

✅ **Evidence Caching**
- Saves evidence envelopes by artifact_id
- Path: `evidence_cache/{entity_id}`

✅ **Session Turn History**
- Path: `sessions/{session_id}/turns`
- Stores query + response pairs

✅ **User Preferences**
- Path: `user_preferences/{user_id}`
- Stores visualization preferences

### ❌ PROBLEM: Missing Session/User Tracking

**Current structure:**
```python
_LOCAL_FIRESTORE_STORE = {
    "sessions": {},           # ← Empty!
    "turns": {},              # ← Empty!
    "evidence_cache": {...},  # ← Has demo data
    "user_preferences": {}    # ← Minimal
}
```

**Session save function:**
```python
def firestore_save_session_turn(session_id: str, turn_data: Dict[str, Any]) -> bool:
    """Appends a new turn to session history in Firestore."""
    turn_data["timestamp"] = datetime.utcnow().isoformat()
    client = get_firestore_client()
    if client:
        try:
            # LIVE FIRESTORE: sessions/{session_id}/turns/{auto_id}
            client.collection("sessions").document(session_id).collection("turns").add(turn_data)
            return True
        except Exception as e:
            logger.warning(f"Error appending session turn: {e}")
    
    # FALLBACK: Local store
    if session_id not in _LOCAL_FIRESTORE_STORE["turns"]:
        _LOCAL_FIRESTORE_STORE["turns"][session_id] = []
    _LOCAL_FIRESTORE_STORE["turns"][session_id].append(turn_data)
    return True
```

**Status:** ✅ Works at runtime, BUT no login/authentication tracking!

---

## 3. BigQuery Tools — Structured Facts

### Current Implementation

```python
def _get_bq_client():
    """Returns BigQuery client if GCP credentials available."""
    global _bq_client, _bq_attempted
    if _bq_attempted:
        return _bq_client
    _bq_attempted = True
    
    # Fast path: no credentials = no blocking
    if not os.getenv("GOOGLE_APPLICATION_CREDENTIALS") and not os.getenv("GCP_PROJECT"):
        logger.info("No GCP credentials. Using local CSV fallback.")
        _bq_client = None
        return None
    
    try:
        from google.cloud import bigquery
        _bq_client = bigquery.Client(project=_PROJECT_ID)
        logger.info(f"BigQuery client initialised (project={_PROJECT_ID})")
        return _bq_client
    except Exception as e:
        logger.warning(f"BigQuery unavailable ({e}). Using CSV fallback.")
        _bq_client = None
        return None
```

### Data Sources (Live BigQuery)

| Table | Purpose | Local Fallback |
|-------|---------|----------------|
| `axiom_data.sprint_planning` | Work items, defects, velocity | `AXIOM_Sprint_Planning.csv` |
| `axiom_data.capacity_planning` | Team allocations, bottlenecks | `AXIOM_Capacity_Planning.csv` |
| `axiom_data.competency_matrix` | Skills, expertise levels | `AXIOM_Competency_Matrix.csv` |
| `axiom_data.pi_planning` | Roadmaps, milestones | `AXIOM_PI_Planning_2026.csv` |
| `axiom_data.test_cases` | ISO 29119 test master store | `test_cases_master_v5.csv` |

### Example Query

```python
def bigquery_list_all_defects() -> List[Dict[str, Any]]:
    """Returns all bug records from axiom_data.sprint_planning."""
    sql = f"""
        SELECT *
        FROM `{_PROJECT_ID}.{_DATASET}.sprint_planning`
        WHERE Type = 'Bug'
        ORDER BY Priority ASC
    """
    rows = _run_bq_query(sql)
    if rows:
        return rows  # ← Live BigQuery
    
    all_rows = _load_csv("sprint_planning")  # ← Fallback to CSV
    return [r for r in all_rows if r.get("Type") == "Bug"]
```

**Status:** ✅ Live BigQuery with robust CSV fallback

---

## 4. Neo4j Knowledge Graph Tools

```python
# agents/tools/neo4j_tools.py

_DYNAMIC_KG = {
    "nodes": [...],  # Requirement, Variant, Component nodes
    "edges": [...]   # PARENT_OF, TARGETS_VARIANT, etc.
}

def neo4j_query_requirement_by_id(requirement_id: str) -> Dict[str, Any]:
    """Queries Neo4j KG for requirement metadata and acceptance criteria."""
    # LIVE: Connects to neo4j://localhost:7687 or cloud instance
    # FALLBACK: Returns from _DYNAMIC_KG dictionary
```

**Status:** ✅ Live Neo4j + in-memory fallback

---

## 5. Authentication & Login — ❌ MISSING

### Current State

**In streamlit_app.py:**
```python
# NO authentication layer!
# Any user can access without logging in

with st.chat_message("user"):
    st.markdown(prompt)

with st.spinner("AXIOM Masters reasoning..."):
    res = run_axiom_orchestration(query=prompt)
```

**In graph.py:**
```python
def run_axiom_orchestration(
    query: str, 
    session_id: str = "default-session",  # ← Static default!
    user_id: str = "default-user"         # ← Static default!
) -> Dict[str, Any]:
    """No authentication check here."""
    return axiom_runner.run(
        query=query, 
        session_id=session_id, 
        user_id=user_id
    )
```

### Missing Components

1. ❌ **Login/Authentication UI** (Streamlit)
2. ❌ **User registration** (Firestore)
3. ❌ **Session management** (user ↔ session_id binding)
4. ❌ **Audit logging** (who did what, when)
5. ❌ **Access control** (role-based permissions)

---

## 6. Proposed Authentication Architecture

### A. Firestore Collections (To Be Added)

```
Firestore Database
├── users/                         # User accounts
│   └── {user_id}/
│       ├── email: "user@company.com"
│       ├── full_name: "John Doe"
│       ├── role: "engineer" | "pm" | "admin"
│       ├── created_at: "2026-10-18T..."
│       ├── last_login: "2026-10-18T..."
│       └── preferences: {...}
│
├── sessions/                      # Active sessions
│   └── {session_id}/
│       ├── user_id: "user_123"
│       ├── created_at: "2026-10-18T..."
│       ├── last_activity: "2026-10-18T..."
│       ├── ip_address: "192.168.1.1"
│       ├── user_agent: "Mozilla/5.0..."
│       └── turns/
│           └── {turn_id}/
│               ├── query: "Analyze GH-ISSUE-107"
│               ├── response: "..."
│               ├── timestamp: "2026-10-18T..."
│               ├── iteration_count: 3
│               └── confidence: 0.92
│
├── audit_log/                     # Comprehensive audit trail
│   └── {user_id}/
│       └── {timestamp}/
│           ├── action: "query_submitted"
│           ├── session_id: "sess_123"
│           ├── query: "..."
│           ├── result_status: "SUCCESS"
│           ├── confidence: 0.92
│           └── ip_address: "192.168.1.1"
│
└── api_keys/                      # For service accounts
    └── {api_key_hash}/
        ├── owner_user_id: "user_123"
        ├── created_at: "2026-10-18T..."
        ├── last_used: "2026-10-18T..."
        ├── permissions: ["query", "read_evidence"]
        └── revoked: false
```

---

## 7. Implementation Plan

### Phase 1: User Authentication (Week 1)

```python
# NEW: agents/tools/auth_tools.py

def firestore_create_user(email: str, full_name: str, role: str = "user") -> str:
    """Create a new user account."""
    user_id = generate_user_id()
    user_doc = {
        "user_id": user_id,
        "email": email,
        "full_name": full_name,
        "role": role,
        "created_at": datetime.utcnow().isoformat(),
        "last_login": None,
        "preferences": {
            "response_style": "visual_first",
            "notify_on_blocker": True
        }
    }
    client.collection("users").document(user_id).set(user_doc)
    return user_id

def firestore_authenticate_user(email: str, password_hash: str) -> Optional[str]:
    """Authenticate user and return user_id."""
    docs = client.collection("users").where("email", "==", email).stream()
    for doc in docs:
        user = doc.to_dict()
        if verify_password(password_hash, user["password_hash"]):
            user_id = user["user_id"]
            # Update last_login
            client.collection("users").document(user_id).update({
                "last_login": datetime.utcnow().isoformat()
            })
            return user_id
    return None

def firestore_create_session(user_id: str, ip_address: str, user_agent: str) -> str:
    """Create a new session for authenticated user."""
    session_id = generate_session_id()
    session_doc = {
        "session_id": session_id,
        "user_id": user_id,
        "created_at": datetime.utcnow().isoformat(),
        "last_activity": datetime.utcnow().isoformat(),
        "ip_address": ip_address,
        "user_agent": user_agent,
        "turn_count": 0
    }
    client.collection("sessions").document(session_id).set(session_doc)
    return session_id

def firestore_log_audit_entry(user_id: str, session_id: str, action: str, metadata: Dict[str, Any]) -> bool:
    """Log action for audit trail."""
    audit_entry = {
        "timestamp": datetime.utcnow().isoformat(),
        "user_id": user_id,
        "session_id": session_id,
        "action": action,
        "metadata": metadata
    }
    client.collection("audit_log").document(f"{user_id}/{datetime.utcnow().isoformat()}").set(audit_entry)
    return True
```

### Phase 2: Streamlit Login UI (Week 1)

```python
# NEW: streamlit_components/auth_panel.py

import streamlit as st
from agents.tools.auth_tools import (
    firestore_authenticate_user,
    firestore_create_session,
    firestore_log_audit_entry
)

def render_login_page():
    """Render login/signup page."""
    st.title("🔐 AXIOM Authentication")
    
    tab_login, tab_signup = st.tabs(["Login", "Sign Up"])
    
    with tab_login:
        email = st.text_input("Email")
        password = st.text_input("Password", type="password")
        
        if st.button("Login"):
            user_id = firestore_authenticate_user(email, hash_password(password))
            if user_id:
                # Create session
                ip_address = st.session_state.get("client_ip", "0.0.0.0")
                user_agent = st.session_state.get("user_agent", "unknown")
                session_id = firestore_create_session(user_id, ip_address, user_agent)
                
                # Log audit
                firestore_log_audit_entry(user_id, session_id, "login", {
                    "ip_address": ip_address
                })
                
                # Store in session
                st.session_state.user_id = user_id
                st.session_state.session_id = session_id
                st.success("Login successful!")
                st.rerun()
            else:
                st.error("Invalid credentials")
    
    with tab_signup:
        signup_email = st.text_input("Email (signup)")
        signup_name = st.text_input("Full Name")
        signup_password = st.text_input("Password (signup)", type="password")
        
        if st.button("Sign Up"):
            # Create user
            user_id = firestore_create_user(
                signup_email, 
                signup_name, 
                role="user"
            )
            # Auto-login
            session_id = firestore_create_session(user_id, "0.0.0.0", "unknown")
            st.session_state.user_id = user_id
            st.session_state.session_id = session_id
            st.success("Account created and logged in!")
            st.rerun()
```

### Phase 3: Guard Orchestrator with Auth (Week 2)

```python
# Updated: streamlit_app.py

import streamlit as st
from streamlit_components.auth_panel import render_login_page

# Check authentication
if "user_id" not in st.session_state:
    render_login_page()
    st.stop()

# User is authenticated
user_id = st.session_state.user_id
session_id = st.session_state.session_id

st.title("AXIOM Multi-Agent Intelligence")

# ... rest of app uses real user_id + session_id

if prompt:
    st.session_state.messages.append({"role": "user", "content": prompt})
    
    res = run_axiom_orchestration(
        query=prompt,
        session_id=session_id,  # ← Real session ID
        user_id=user_id         # ← Real user ID
    )
    
    # Log query
    firestore_log_audit_entry(user_id, session_id, "query_submitted", {
        "query_length": len(prompt),
        "master": res.get("target_master"),
        "confidence": res.get("confidence")
    })
```

---

## 8. Runtime Session Data Flow

### Current (Minimal)

```
Streamlit App
    │
    ├─ user_id: "default-user"     ← Hard-coded!
    └─ session_id: "default-session" ← Hard-coded!
         │
         ▼
    run_axiom_orchestration()
         │
         ├─ firestore_save_session_turn(session_id, turn_data)
         │     │
         │     ├─ Live: sessions/{session_id}/turns/{turn_id}
         │     └─ Fallback: _LOCAL_FIRESTORE_STORE["turns"][session_id]
         │
         └─ firestore_cache_evidence(entity_id, evidence)
               │
               ├─ Live: evidence_cache/{entity_id}
               └─ Fallback: _LOCAL_FIRESTORE_STORE["evidence_cache"]
```

### Proposed (With Auth)

```
Streamlit App
    │
    ├─ Login Page (NEW)
    │    │
    │    ├─ firestore_authenticate_user(email, password)
    │    ├─ firestore_create_session(user_id, ip, user_agent)
    │    └─ firestore_log_audit_entry("login", {...})
    │
    ├─ user_id: "user_123"         ← From Firestore
    └─ session_id: "sess_456"       ← Generated at login
         │
         ▼
    run_axiom_orchestration(query, session_id, user_id)
         │
         ├─ firestore_save_session_turn(session_id, turn_data)
         │     └─ sessions/{session_id}/turns/{turn_id}
         │           ├─ user_id: "user_123"
         │           ├─ query: "..."
         │           └─ response: "..."
         │
         ├─ firestore_cache_evidence(entity_id, evidence)
         │     └─ evidence_cache/{entity_id}
         │           └─ metadata: {user_id, session_id}
         │
         └─ firestore_log_audit_entry(user_id, session_id, "query_submitted", {...})
               └─ audit_log/{user_id}/{timestamp}
                     ├─ action: "query_submitted"
                     ├─ query_length: 42
                     ├─ confidence: 0.92
                     └─ ip_address: "192.168.1.1"
```

---

## 9. Summary Table

| Component | Current Status | Live System | Fallback | Auth | Audit |
|-----------|---|---|---|---|---|
| **Firestore Tools** | ✅ Works | ✅ Cloud Firestore | ✅ In-memory dict | ❌ NO | ⚠️ Minimal |
| **BigQuery Tools** | ✅ Works | ✅ Live BQ | ✅ CSV files | ✅ Via GCP | ✅ BQ logs |
| **Neo4j Tools** | ✅ Works | ✅ Live Neo4j | ✅ In-memory dict | ✅ Via Neo4j auth | ❌ NO |
| **Session Management** | ⚠️ Partial | ✅ Sessions created | ✅ Local dict | ❌ NO | ❌ NO |
| **User Authentication** | ❌ MISSING | ❌ NO | ❌ NO | ❌ NO | ❌ NO |
| **Audit Logging** | ⚠️ Minimal | ❌ NO | ⚠️ Logging only | ❌ NO | ❌ NO |
| **Access Control** | ❌ MISSING | ❌ NO | ❌ NO | ❌ NO | ❌ NO |

---

## 10. Recommendations

### Immediate (MVP)
1. ✅ Keep Firestore tools as-is (working for evidence caching)
2. ✅ Keep BigQuery tools as-is (robust CSV fallback)
3. ❌ Add basic login UI (Streamlit)
4. ✅ Add user authentication functions (Firestore)
5. ✅ Add audit logging functions (Firestore)

### Future (Production)
1. Add password hashing (bcrypt)
2. Add session token validation
3. Add rate limiting per user
4. Add role-based access control (RBAC)
5. Add data encryption at rest
6. Add compliance audit exports (GDPR)

---

**Status: Tools are solid, but authentication layer is completely missing. Recommend implementing Phase 1 (login UI) before production deployment.**
