"""
GitHub Tools for AXIOM Defect Intelligence.
Fetches, caches, and searches live issues from GitHub repository:
https://github.com/JyothiLakshmikanth/EKey2W/issues
"""

import os
import re
import json
import logging
from typing import Dict, Any, List, Optional
import requests

logger = logging.getLogger("axiom.tools.github")

DEFAULT_REPO = "JyothiLakshmikanth/EKey2W"
_CACHED_ISSUES: List[Dict[str, Any]] = []


def _get_github_token() -> Optional[str]:
    """Retrieve GitHub token from env or .env file."""
    token = os.getenv("GITHUB_TOKEN")
    if not token and os.path.exists(".env"):
        try:
            with open(".env", "r", encoding="utf-8") as f:
                for line in f:
                    if line.strip().startswith("GITHUB_TOKEN="):
                        token = line.strip().split("=", 1)[1].strip()
                        break
        except Exception:
            pass
    return token


def github_list_all_issues(repo: str = DEFAULT_REPO, force_refresh: bool = False) -> List[Dict[str, Any]]:
    """
    Fetches all open and closed issues from the target GitHub repository.
    Uses in-memory caching to minimize GitHub API rate limiting.
    """
    global _CACHED_ISSUES
    if _CACHED_ISSUES and not force_refresh:
        return _CACHED_ISSUES

    token = _get_github_token()
    headers = {
        "Accept": "application/vnd.github+json",
        "User-Agent": "axiom-defect-agent/1.0"
    }
    if token:
        headers["Authorization"] = f"Bearer {token}"

    all_issues = []
    page = 1
    per_page = 100

    try:
        while True:
            url = f"https://api.github.com/repos/{repo}/issues?state=all&per_page={per_page}&page={page}"
            resp = requests.get(url, headers=headers, timeout=10)
            if resp.status_code != 200:
                logger.warning(f"GitHub API error fetching {repo} page {page}: {resp.status_code} - {resp.text[:100]}")
                break
            items = resp.json()
            if not items or not isinstance(items, list):
                break
            all_issues.extend(items)
            if len(items) < per_page:
                break
            page += 1
            if page > 5:  # Safety cap at 500 issues
                break

        if all_issues:
            _CACHED_ISSUES = all_issues
            logger.info(f"GitHub: Cached {len(all_issues)} issues from {repo}")
    except Exception as e:
        logger.error(f"Failed to fetch GitHub issues from {repo}: {e}")

    return _CACHED_ISSUES


def github_get_issue_by_number(issue_number: int, repo: str = DEFAULT_REPO) -> Optional[Dict[str, Any]]:
    """Retrieve a single GitHub issue by its issue number."""
    issues = github_list_all_issues(repo)
    for issue in issues:
        if issue.get("number") == issue_number:
            return issue
    return None


def github_find_matching_issue(query: str, repo: str = DEFAULT_REPO) -> Optional[Dict[str, Any]]:
    """
    Finds the most relevant GitHub issue matching a user query:
    1. By explicit issue number (e.g. #2, issue 2, GH-2, GH-ISSUE-2)
    2. By exact title match
    3. By token/keyword overlap in title and body
    """
    issues = github_list_all_issues(repo)
    if not issues:
        return None

    # 1. Check for explicit issue number
    num_match = re.search(r'(?:#|issue\s*|gh-issue-|gh-)(\d+)\b', query, re.IGNORECASE)
    if num_match:
        target_num = int(num_match.group(1))
        for issue in issues:
            if issue.get("number") == target_num:
                logger.info(f"GitHub: Matched issue #{target_num} by explicit number")
                return issue

    # 2. Check for exact title match or substring in query
    clean_query = query.lower()
    for issue in issues:
        title = issue.get("title", "").lower()
        if title and (title in clean_query or clean_query in title):
            logger.info(f"GitHub: Exact/substring title match on #{issue.get('number')}: {issue.get('title')}")
            return issue

    # 3. Score by meaningful keyword overlap
    stop_words = {"the", "for", "bug", "defect", "triage", "and", "show", "visually", "analysis", "preform", "perform", "with", "what", "how", "why", "from", "this"}
    query_tokens = set(re.findall(r'[a-zA-Z0-9]{3,}', clean_query)) - stop_words

    best_issue = None
    best_score = 0

    for issue in issues:
        title_tokens = set(re.findall(r'[a-zA-Z0-9]{3,}', issue.get("title", "").lower()))
        body_tokens = set(re.findall(r'[a-zA-Z0-9]{3,}', (issue.get("body") or "").lower()))

        # Heavily weight title matches over body matches
        title_overlap = query_tokens.intersection(title_tokens)
        body_overlap = query_tokens.intersection(body_tokens)
        score = (len(title_overlap) * 3) + len(body_overlap)

        if score > best_score:
            best_score = score
            best_issue = issue

    if best_issue and best_score >= 2:
        logger.info(f"GitHub: Keyword match on #{best_issue.get('number')}: {best_issue.get('title')} (score={best_score})")
        return best_issue

    return None


def format_github_issue_evidence(issue: Dict[str, Any]) -> Dict[str, Any]:
    """
    Normalizes a GitHub issue into an authoritative EvidenceEnvelope.
    Extracts linked requirements and test cases mentioned in the issue body.
    """
    num = issue.get("number")
    title = issue.get("title", "")
    body = issue.get("body", "") or ""

    # Extract linked requirements (REQ-L...) and test cases (TC-...)
    linked_reqs = list(set(re.findall(r'REQ-[A-Z0-9-]+', body)))
    linked_tcs = list(set(re.findall(r'TC-[A-Z0-9-]+', body)))

    payload = {
        "Type": "GitHub Issue",
        "Id": f"GH-ISSUE-{num}",
        "Issue_Number": num,
        "Summary": title,
        "Title": title,
        "Status": issue.get("state", "open").capitalize(),
        "State": issue.get("state"),
        "Labels": [l.get("name") if isinstance(l, dict) else l for l in issue.get("labels", [])],
        "Author": issue.get("user", {}).get("login"),
        "URL": issue.get("html_url"),
        "Body": body,
        "Linked_Requirements": linked_reqs,
        "Linked_Test_Cases": linked_tcs,
        "Created_At": issue.get("created_at"),
        "Updated_At": issue.get("updated_at")
    }

    return {
        "artifact_id": f"GH-ISSUE-{num}",
        "artifact_type": "github_issue_record",
        "source_system": "github_repository",
        "source_uri": issue.get("html_url", f"https://github.com/{DEFAULT_REPO}/issues/{num}"),
        "version": "1.0",
        "updated_at": issue.get("updated_at", "2026-10-18T00:00:00Z"),
        "authoritative": True,
        "synthetic": False,
        "quality_status": "verified",
        "payload": payload
    }
