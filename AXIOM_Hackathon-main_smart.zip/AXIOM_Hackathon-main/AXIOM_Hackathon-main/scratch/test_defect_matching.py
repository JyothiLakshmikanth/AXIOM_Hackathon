import sys
import os
sys.path.insert(0, os.path.abspath("."))

from agents.defect_agent import defect_agent

queries = [
    "Preform the defect triage for the BUG [BUG] BLE unlock rejects a signal exactly at the configured threshold and show visually the analysis",
    "What is the defect triage for latency on low power phone?",
    "Analyze the revoked key defect",
    "Triage TWK-108",
    "What is the defect for digital key enrollment?"
]

for q in queries:
    res = defect_agent.execute_react_loop({"query": q})
    print(f"\nQuery: {q}")
    ev = res["evidences"][0] if res["evidences"] else {}
    print(f"  -> Matched Artifact ID: {ev.get('artifact_id')}")
    print(f"  -> Summary: {res.get('summary')}")
    print(f"  -> Ticket Summary: {ev.get('payload', {}).get('Summary')}")
