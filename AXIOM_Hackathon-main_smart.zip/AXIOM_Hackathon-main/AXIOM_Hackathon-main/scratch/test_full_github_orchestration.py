import sys
import os
sys.path.insert(0, os.path.abspath("."))

from orchestrator.graph import run_axiom_orchestration

query = "Preform the defect triage for the BUG [BUG] BLE unlock rejects a signal exactly at the configured threshold and show visually the analysis"

print("Running full AXIOM orchestration...")
res = run_axiom_orchestration(query=query)

print("\n=== FINAL ORCHESTRATION RESULT ===")
print("Target Master:", res.get("target_master"))
print("Target Capability:", res.get("target_capability"))
print("Confidence:", res.get("confidence_score"))
print("Visual Type:", res.get("visual_artifact", {}).get("visual_type"))
print("Evidence count:", len(res.get("evidence_envelopes", [])))
for ev in res.get("evidence_envelopes", []):
    print(f"  - [{ev.get('artifact_id')}] ({ev.get('artifact_type')}): {ev.get('source_uri')}")

print("\n=== MARKDOWN SYNTHESIS (first 600 chars) ===")
print(res.get("final_output_markdown", "")[:600])

if res.get("visual_artifact", {}).get("fallback_mermaid"):
    print("\n=== MERMAID DIAGRAM ===")
    print(res.get("visual_artifact", {}).get("fallback_mermaid"))
