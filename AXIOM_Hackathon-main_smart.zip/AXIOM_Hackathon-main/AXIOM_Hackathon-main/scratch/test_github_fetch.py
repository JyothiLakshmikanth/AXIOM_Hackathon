import os
import requests

token = None
if os.path.exists(".env"):
    with open(".env", "r") as f:
        for line in f:
            if line.strip().startswith("GITHUB_TOKEN="):
                token = line.strip().split("=", 1)[1].strip()

headers = {
    "Accept": "application/vnd.github+json",
    "User-Agent": "axiom-agent"
}
if token:
    headers["Authorization"] = f"Bearer {token}"

all_issues = []
page = 1
while True:
    url = f"https://api.github.com/repos/JyothiLakshmikanth/EKey2W/issues?state=all&per_page=100&page={page}"
    r = requests.get(url, headers=headers)
    if r.status_code != 200:
        print("Error fetching page", page, r.status_code)
        break
    data = r.json()
    if not data or not isinstance(data, list):
        break
    all_issues.extend(data)
    page += 1

print(f"Total issues fetched across all pages: {len(all_issues)}")
for i in all_issues:
    title = i.get("title", "")
    body = i.get("body", "") or ""
    num = i.get("number")
    t_lower = title.lower()
    b_lower = body.lower()
    if any(k in t_lower or k in b_lower for k in ["reject", "threshold", "signal", "boundary", "ble"]):
        print(f"#{num}: {title}")
        print(f"   labels: {[l.get('name') for l in i.get('labels', [])]}")
        print(f"   url: {i.get('html_url')}")
        for bl in body.splitlines():
            if any(k in bl.lower() for k in ["reject", "threshold", "signal", "boundary", "ble"]):
                print(f"   line: {bl}")
        print("-" * 50)
