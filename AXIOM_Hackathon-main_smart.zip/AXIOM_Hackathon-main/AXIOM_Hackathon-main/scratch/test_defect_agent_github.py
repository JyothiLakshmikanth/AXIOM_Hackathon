import sys
import os
sys.path.insert(0, os.path.abspath("."))

from agents.defect_agent import defect_agent

query = "Preform the defect triage for the BUG [BUG] BLE unlock rejects a signal exactly at the configured threshold and show visually the analysis"

result = defect_agent.execute_react_loop({"query": query})

print("=== DEFECT AGENT EXECUTION RESULT ===")
print("Agent ID:", result["agent_id"])
print("Status:", result["execution_status"])
print("Summary:", result["summary"])
print("\nEvidences count:", len(result["evidences"]))
for ev in result["evidences"]:
    print("  Artifact ID:", ev["artifact_id"])
    print("  Type:", ev["artifact_type"])
    print("  Source System:", ev["source_system"])
    print("  Source URI:", ev["source_uri"])
    payload = ev["payload"]
    print("  Title:", payload.get("Title") or payload.get("Summary"))
    print("  Status/State:", payload.get("Status") or payload.get("State"))
    print("  Linked REQs:", payload.get("Linked_Requirements"))
    print("  Linked TCs:", payload.get("Linked_Test_Cases"))
    print("  Body snippet:", str(payload.get("Body"))[:200], "...\n")

print("Findings:")
print("  Severity:", result["findings"].get("severity"))
print("  Urgency:", result["findings"].get("urgency"))
print("  Leakage Analysis:", result["findings"].get("leakage_analysis"))
