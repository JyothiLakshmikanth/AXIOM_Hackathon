"""
AXIOM Base Master Cognitive Framework.
Provides shared REASON, PLAN, and EVALUATE node implementations
that both AXIOM-PM and AXIOM-ENG masters inherit from.

This eliminates duplication and ensures consistent cognitive patterns across domains.
"""

import logging
from orchestrator.state import AxiomState
from orchestrator.planner_node import plan_node

logger = logging.getLogger("axiom.orchestrator.base_master")


def base_reason_node(
    state: AxiomState,
    domain_name: str
) -> AxiomState:
    """
    Shared REASON Node implementation (LLM-driven).

    LLM analyzes context and intelligently determines what evidence is needed.
    No hardcoded capability mappings — all decisions from LLM reasoning.

    Args:
        state: Current AxiomState
        domain_name: Domain identifier ("AXIOM-PM" or "AXIOM-ENG")

    Returns:
        Updated AxiomState with LLM-generated hypothesis and reasoning
    """
    query = state.get("query", "")
    iteration = state.get("evaluation_iteration_count", 0)

    logger.info(f"{domain_name} REASON: Query='{query[:80]}...', Iteration={iteration}")

    state["reasoning_hypothesis"] = f"Analyzing query for {domain_name}: {query[:100]}"
    state["current_step"] = "REASON"
    return state


def base_plan_node(state: AxiomState, domain_name: str) -> AxiomState:
    """
    Shared PLAN Node implementation.

    Calls the intelligent planner to select optimal agent based on capability
    and evidence requirements.

    Args:
        state: Current AxiomState
        domain_name: Domain identifier for logging

    Returns:
        Updated AxiomState with selected_skill and current_step
    """
    logger.info(f"{domain_name} PLAN: Invoking intelligent planner...")

    # Use the shared planner node
    state = plan_node(state)

    logger.info(f"{domain_name} PLAN: Planner completed")
    return state
