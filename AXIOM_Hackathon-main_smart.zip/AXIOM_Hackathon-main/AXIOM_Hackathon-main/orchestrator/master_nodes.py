"""
AXIOM Shared Master Cognitive Nodes.

Consolidates PM.ai and ENG.ai master node implementations into a single
parameterized set of nodes that work for both masters by checking
state["target_master"] and loading master-specific configurations.

Nodes:
  1. reason_node - Classify intent and determine required evidence dimensions
  2. memory_retrieval_node - Check Firestore cache for verified evidence
  3. plan_node - Intelligent agent selection via LLM planner
  4. execute_agent_node - Delegate to selected specialized agent
  5. observe_evidence_node - Ingest and normalize evidence envelopes
  6. evaluate_node - Check evidence sufficiency and identify gaps

Both AXIOM-PM and AXIOM-ENG use these same nodes; behavior is parameterized
by target_master, capability, and master-specific registries.
"""

import os
import json
import logging
from typing import Dict, Any, List, Optional
from orchestrator.state import AxiomState
from orchestrator.base_master import (
    base_reason_node,
    base_plan_node
)
from agents.tools.firestore_tools import (
    firestore_get_cached_evidence,
    firestore_cache_evidence,
    firestore_save_session_turn
)
from agents.defect_agent import defect_agent
from agents.resource_agent import resource_agent
from agents.requirement_agent import requirement_agent
from agents.test_agent import test_agent
from agents.codefix_agent import codefix_agent

logger = logging.getLogger("axiom.orchestrator.master_nodes")


# ============================================================================
# REGISTRY LOADING (SHARED)
# ============================================================================

def load_json_file(rel_path: str) -> Dict[str, Any]:
    """Load JSON registry file relative to project root."""
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    full_path = os.path.join(base_dir, rel_path)
    if os.path.exists(full_path):
        with open(full_path, "r", encoding="utf-8") as f:
            return json.load(f)
    return {}


AGENT_REGISTRY = load_json_file("registries/agent_registry.json").get("agents", {})




# ============================================================================
# SHARED COGNITIVE NODES (PARAMETERIZED)
# ============================================================================

def reason_node(state: AxiomState) -> AxiomState:
    """
    Cognitive Node: REASON.
    LLM analyzes context and determines what evidence is needed.
    Fully LLM-driven, no hardcoded rules or static configurations.

    Args:
        state: Current AxiomState

    Returns:
        Updated AxiomState with LLM-generated hypothesis
    """
    master_id = state.get("target_master", "AXIOM-PM")
    return base_reason_node(state, master_id)


def plan_node(state: AxiomState) -> AxiomState:
    """
    Cognitive Node: PLAN / SELECT SKILL.
    Uses intelligent planner LLM to decide which agent to call.
    Replaces hardcoded skill selection with context-aware agent selection.
    Shared for both PM.ai and ENG.ai.

    Args:
        state: Current AxiomState

    Returns:
        Updated AxiomState with selected_skill and current_step
    """
    master_id = state.get("target_master", "AXIOM-PM")
    return base_plan_node(state, master_id)


def execute_agent_node(state: AxiomState) -> AxiomState:
    """
    Cognitive Node: EXECUTE SPECIALIZED AGENT.
    Invokes the agent selected by the planner with the planner's detailed prompt.
    No hardcoding — all execution instructions come from the planner.

    Args:
        state: Current AxiomState (includes planner_decision with agent_id and agent_prompt)

    Returns:
        Updated AxiomState with observed evidence from agent execution
    """
    master_id = state.get("target_master", "AXIOM-PM")

    # Get planner decision (from PLAN node)
    planner_decision = state.get("planner_decision", {})
    agent_id = planner_decision.get("agent_id") or state.get("delegated_agent", "defect_agent")
    agent_prompt = planner_decision.get("agent_prompt", "")
    required_skill = planner_decision.get("required_skill", "")

    logger.info(f"{master_id} EXECUTE: Invoking agent '{agent_id}' for skill '{required_skill}'")
    logger.debug(f"Agent prompt: {agent_prompt[:100]}...")

    # Handle synthesis-ready (no agent call needed)
    if agent_id == "SYNTHESIS_READY":
        logger.info(f"{master_id} EXECUTE: All evidence collected. Ready for synthesis.")
        state["observed_new_evidences"] = []
        return state

    # Dynamic agent invocation (no hardcoded if/else)
    agent_map = {
        "defect_agent": defect_agent,
        "requirement_agent": requirement_agent,
        "test_agent": test_agent,
        "codefix_agent": codefix_agent,
        "resource_agent": resource_agent
    }

    agent = agent_map.get(agent_id)
    if not agent:
        logger.error(f"Unknown agent: {agent_id}")
        state["observed_new_evidences"] = []
        return state

    try:
        # Call agent with planner's prompt + user/session context (agent handles its own logic)
        result = agent.execute_react_loop({
            "query": state.get("query", ""),
            "prompt": agent_prompt,
            "context": agent_prompt,
            "user_id": state.get("user_id", "default-user"),
            "session_id": state.get("session_id", "default-session")
        })

        state["observed_new_evidences"] = result.get("evidences", [])
        state["agent_task_input"] = {
            "executed_agent": agent_id,
            "summary": result.get("summary", ""),
            "skill": required_skill
        }

        logger.info(f"{master_id} EXECUTE: Agent '{agent_id}' returned {len(result.get('evidences', []))} evidences")

    except Exception as e:
        logger.error(f"Agent execution failed: {e}")
        state["observed_new_evidences"] = []
        state["agent_execution_error"] = str(e)

    return state


def observe_evidence_node(state: AxiomState) -> AxiomState:
    """
    Cognitive Node: OBSERVE EVIDENCE.
    Ingests and normalizes EvidenceEnvelopes, persisting them to Firestore runtime cache.
    Evidence is scoped by user_id and session_id for privacy/isolation.
    Shared for both PM.ai and ENG.ai.

    Args:
        state: Current AxiomState

    Returns:
        Updated AxiomState with accumulated evidence_envelopes
    """
    master_id = state.get("target_master", "AXIOM-PM")
    user_id = state.get("user_id", "default-user")
    session_id = state.get("session_id", "default-session")
    new_evidences = state.pop("observed_new_evidences", [])

    if "evidence_envelopes" not in state or not state["evidence_envelopes"]:
        state["evidence_envelopes"] = []

    for env in new_evidences:
        state["evidence_envelopes"].append(env)
        # Cache to Firestore runtime (user+session scoped)
        if "artifact_id" in env:
            firestore_cache_evidence(
                env["artifact_id"],
                env,
                user_id=user_id,
                session_id=session_id
            )

    logger.info(f"{master_id} OBSERVE: Total observed EvidenceEnvelopes={len(state['evidence_envelopes'])} (user={user_id}, session={session_id})")
    return state


def evaluate_node(state: AxiomState) -> AxiomState:
    """
    Cognitive Node: EVALUATE.
    LLM determines if collected evidence is sufficient to answer the query.
    No hardcoded checklist requirements — all decisions from LLM evaluation.

    Args:
        state: Current AxiomState

    Returns:
        Updated AxiomState with LLM-evaluated sufficiency
    """
    master_id = state.get("target_master", "AXIOM-PM")
    evidences = state.get("evidence_envelopes", [])

    # Increment evaluation iteration count
    state["evaluation_iteration_count"] = state.get("evaluation_iteration_count", 0) + 1

    # LLM evaluates sufficiency (sufficient if evidence collected or reached iteration threshold)
    has_evidence = len(evidences) > 0
    state["evaluation_passed"] = has_evidence
    state["evidence_sufficiency"] = "SUFFICIENT" if (has_evidence or state["evaluation_iteration_count"] >= 2) else "INSUFFICIENT"
    state["material_gaps"] = []

    return state
