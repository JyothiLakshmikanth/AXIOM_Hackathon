"""
Smart Defect Assignment Tool for AXIOM
=========================================

Given a bug/defect ticket:
  1. Analyzes the problem domain and required skills
  2. Searches team competency database for best-matched engineers
  3. Checks workload and availability
  4. Provides intelligent assignment recommendations
  5. Posts RCA summary to bug ticket via HITL (Human-In-The-Loop)

This module extends resource_agent.py with skill-based intelligent assignment.
Supports JIRA/GitHub Issues/Notion bug tracking integration.
"""

import os
import json
import logging
import re
import requests
from typing import Dict, Any, List, Optional, Tuple
from pathlib import Path
from datetime import datetime
from enum import Enum

logger = logging.getLogger("axiom.agents.tools.smart_assignment")

# Get project root
PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent


class CompetencyLevel(Enum):
    """Team member competency levels."""
    EXPERT = "expert"
    ADVANCED = "advanced"
    INTERMEDIATE = "intermediate"
    BEGINNER = "beginner"


class AssignmentDecision(Enum):
    """Assignment decision status."""
    ASSIGNED = "assigned"
    ESCALATED = "escalated"
    PENDING_REVIEW = "pending_review"
    NO_CAPACITY = "no_capacity"


def _load_team_competencies() -> Dict[str, Dict[str, Any]]:
    """
    Load team member competency profiles from CSV files.
    
    Reads from:
    - AXIOM_Competency_Matrix.csv (skills and levels)
    - AXIOM_Capacity_Planning.csv (capacity and allocation)
    
    Expected structure:
    {
        "engineer_name": {
            "skills": ["Python", "FastAPI", "Neo4j"],
            "competency_levels": {"Python": "expert", "FastAPI": "advanced"},
            "current_capacity_percent": 75,
            "max_capacity_percent": 85,
            "active_tickets": [],
            "team": "Backend Platform",
            "role": "Senior Engineer",
            "location": "Bengaluru"
        }
    }
    """
    import csv
    
    team_data = {}
    
    # Try to load from actual CSV files first
    csv_paths = [
        PROJECT_ROOT / "AXIOM_Hackathon-main" / "data" / "AXIOM_Competency_Matrix.csv",
        PROJECT_ROOT / "data" / "AXIOM_Competency_Matrix.csv",
    ]
    
    competency_csv = None
    for path in csv_paths:
        if path.exists():
            competency_csv = path
            break
    
    if competency_csv:
        try:
            # Load competency matrix
            competencies_by_engineer = {}
            
            with open(competency_csv, 'r', encoding='utf-8') as f:
                reader = csv.DictReader(f)
                for row in reader:
                    engineer = row.get('associate', '').strip()
                    skill = row.get('skill', '').strip()
                    current_level = row.get('current_level', '').strip()
                    role = row.get('role', '').strip()
                    domain = row.get('domain', '').strip()
                    
                    if not engineer or not skill:
                        continue
                    
                    if engineer not in competencies_by_engineer:
                        competencies_by_engineer[engineer] = {
                            'skills': [],
                            'competency_levels': {},
                            'role': role,
                            'domain': domain
                        }
                    
                    competencies_by_engineer[engineer]['skills'].append(skill)
                    # Map L1-L4 to competency levels
                    level_map = {'L1': 'beginner', 'L2': 'intermediate', 'L3': 'advanced', 'L4': 'expert'}
                    competencies_by_engineer[engineer]['competency_levels'][skill] = level_map.get(current_level, 'beginner')
            
            logger.info(f"Loaded {len(competencies_by_engineer)} engineers from competency matrix")
            
            # Now try to load capacity information
            capacity_paths = [
                PROJECT_ROOT / "AXIOM_Hackathon-main" / "data" / "AXIOM_Capacity_Planning.csv",
                PROJECT_ROOT / "data" / "AXIOM_Capacity_Planning.csv",
            ]
            
            capacity_csv = None
            for path in capacity_paths:
                if path.exists():
                    capacity_csv = path
                    break
            
            if capacity_csv:
                with open(capacity_csv, 'r', encoding='utf-8') as f:
                    reader = csv.DictReader(f)
                    for row in reader:
                        engineer = row.get('Associate', '').strip()
                        if engineer in competencies_by_engineer:
                            allocation = float(row.get('Allocation_%', '0')) or 0
                            location = row.get('Location', 'Unknown').strip()
                            
                            competencies_by_engineer[engineer]['current_capacity_percent'] = allocation
                            competencies_by_engineer[engineer]['max_capacity_percent'] = 85  # Standard max
                            competencies_by_engineer[engineer]['location'] = location
                            competencies_by_engineer[engineer]['active_tickets'] = []
            
            team_data = competencies_by_engineer
            
            if team_data:
                logger.info(f"Loaded real team data for {len(team_data)} engineers from AXIOM files")
                return team_data
                
        except Exception as e:
            logger.warning(f"Error loading from CSV files: {e}")
    
    # Fallback to sample data if CSV loading fails
    logger.warning("Could not load from CSV files. Using sample data for testing.")
    return _get_sample_competencies()


def _get_sample_competencies() -> Dict[str, Dict[str, Any]]:
    """
    Return sample competency data based on actual AXIOM team.
    Real team members from E-Key 2W project.
    """
    return {
        "JyothiLakshmikanth": {
            "skills": [
                "System Design & Architecture", "Security Architecture", "Cloud Architecture",
                "Vehicle Communication", "Design Patterns", "Test Automation", "API Testing",
                "Mobile Automation", "Performance Testing", "Vehicle ECU Communication",
                "Ride Authorization", "Gateway Implementation", "State Management",
                "Testing & Diagnostics"
            ],
            "competency_levels": {
                "System Design & Architecture": "expert",
                "Design Patterns": "expert",
                "Security Architecture": "advanced",
                "Cloud Architecture": "advanced",
                "Test Automation": "advanced",
                "Vehicle ECU Communication": "advanced",
                "State Management": "advanced"
            },
            "current_capacity_percent": 90,  # Multiple roles
            "max_capacity_percent": 100,
            "active_tickets": [],
            "team": "Architecture & QA",
            "role": "System Architect / QA Automation Engineer",
            "location": "Bengaluru/Pune",
            "seniority": "senior",
            "experience_years": 15
        },
        "bhavya2642-collab": {
            "skills": [
                "iOS Development", "Android Development", "Mobile Security", "NFC/BLE Protocol",
                "Cryptography Basics", "API Integration", "Cloud Architecture", 
                "Key Management Service", "Database Design", "Cloud Security",
                "Microservices", "DevOps"
            ],
            "competency_levels": {
                "iOS Development": "expert",
                "API Integration": "expert",
                "Android Development": "advanced",
                "NFC/BLE Protocol": "advanced",
                "Cloud Architecture": "advanced",
                "Microservices": "intermediate"
            },
            "current_capacity_percent": 80,
            "max_capacity_percent": 85,
            "active_tickets": [],
            "team": "Mobile & Cloud",
            "role": "Mobile Engineer / Cloud Engineer / DevOps Engineer",
            "location": "Bengaluru",
            "seniority": "senior",
            "experience_years": 8
        },
        "manjunathan-j": {
            "skills": [
                "iOS Development", "UI/UX Implementation", "Mobile Testing",
                "Bluetooth Integration", "Performance Optimization",
                "Cryptography", "Security Architecture", "Vehicle Security",
                "Authentication Protocols", "Secure Key Exchange", "Threat Modeling"
            ],
            "competency_levels": {
                "Cryptography": "expert",
                "Authentication Protocols": "expert",
                "Secure Key Exchange": "expert",
                "UI/UX Implementation": "expert",
                "iOS Development": "advanced",
                "Security Architecture": "advanced",
                "Vehicle Security": "advanced"
            },
            "current_capacity_percent": 70,
            "max_capacity_percent": 85,
            "active_tickets": [],
            "team": "Security & Mobile",
            "role": "Mobile Engineer / Security Engineer / Product Owner",
            "location": "Pune",
            "seniority": "senior",
            "experience_years": 6
        },
        "Pavi2604": {
            "skills": [
                "Vehicle ECU Communication", "CAN Bus Protocol", "Vehicle Proximity Sensing",
                "Access Control Logic", "Real-time Systems", "Low-Power Design",
                "Test Planning", "Manual Testing", "System Integration Testing",
                "Test Case Design", "Defect Management", "UX Engineering"
            ],
            "competency_levels": {
                "Vehicle ECU Communication": "expert",
                "CAN Bus Protocol": "expert",
                "Manual Testing": "expert",
                "Vehicle Proximity Sensing": "advanced",
                "Access Control Logic": "advanced",
                "Real-time Systems": "advanced",
                "Test Planning": "advanced"
            },
            "current_capacity_percent": 100,  # Full capacity (multiple roles)
            "max_capacity_percent": 100,
            "active_tickets": [],
            "team": "Vehicle & QA",
            "role": "Vehicle Software Engineer / QA Engineer / UX Engineer",
            "location": "Bengaluru",
            "seniority": "senior",
            "experience_years": 12
        },
    }


def extract_required_skills(bug_description: str, bug_summary: str) -> List[Tuple[str, float]]:
    """
    Extract required skills from bug description using pattern matching.
    Maps generic tech terms to AXIOM domain-specific competency skills.
    
    Returns list of (skill, confidence) tuples sorted by confidence descending.
    """
    # Map generic tech terms to AXIOM competency skills
    tech_to_axiom_skills = {
        # Database/Backend Performance Issues -> Database Design
        "PostgreSQL": [("Database Design", 0.85), ("API Development", 0.6), ("Cloud Architecture", 0.5)],
        "MySQL": [("Database Design", 0.85), ("API Development", 0.6)],
        "MongoDB": [("Database Design", 0.80), ("API Development", 0.65)],
        "Database": [("Database Design", 0.90), ("API Development", 0.5)],
        "SQL": [("Database Design", 0.85), ("API Development", 0.5)],
        "Query": [("Database Design", 0.80), ("API Development", 0.5)],
        
        # Caching Issues -> Cache Management / Performance Optimization
        "Redis": [("Performance Optimization", 0.85), ("API Development", 0.6), ("Microservices", 0.5)],
        "Cache": [("Performance Optimization", 0.85), ("CI/CD Pipeline", 0.4)],
        "Memory": [("Performance Optimization", 0.85), ("Low-Power Design", 0.5)],
        
        # Performance Issues
        "Performance": [("Performance Optimization", 0.90)],
        "Timeout": [("Performance Optimization", 0.85), ("API Testing", 0.6)],
        "Slow": [("Performance Optimization", 0.85), ("API Testing", 0.6)],
        "Latency": [("Performance Optimization", 0.90)],
        
        # Frontend/Mobile Issues
        "React": [("UI/UX Implementation", 0.85), ("Mobile Design Patterns", 0.7)],
        "JavaScript": [("API Integration", 0.80), ("UI/UX Implementation", 0.7), ("Mobile Design Patterns", 0.6)],
        "Mobile": [("Mobile Design Patterns", 0.90), ("iOS Development", 0.8), ("Android Development", 0.8)],
        "iOS": [("iOS Development", 0.95)],
        "Android": [("Android Development", 0.95)],
        "Frontend": [("UI/UX Implementation", 0.85), ("Mobile Design Patterns", 0.7)],
        "UI": [("UI/UX Implementation", 0.90), ("UI Design", 0.85)],
        "UX": [("UI Design", 0.90), ("User Research", 0.8)],
        "CSS": [("UI/UX Implementation", 0.80), ("UI Design", 0.75)],
        
        # Security Issues
        "Security": [("Security Architecture", 0.90), ("Cryptography", 0.8)],
        "XSS": [("Security Architecture", 0.95), ("Mobile Security", 0.7)],
        "Injection": [("Security Architecture", 0.90), ("Cryptography", 0.6)],
        "Authentication": [("Authentication Protocols", 0.95), ("Secure Key Exchange", 0.8)],
        "Cryptography": [("Cryptography", 0.95), ("Secure Key Exchange", 0.85)],
        "Vulnerability": [("Security Architecture", 0.85), ("Threat Modeling", 0.8)],
        
        # Race Condition / Concurrency
        "Race": [("State Management", 0.90), ("Real-time Systems", 0.8)],
        "Thread": [("State Management", 0.85), ("Real-time Systems", 0.8)],
        "Concurrent": [("State Management", 0.85), ("Real-time Systems", 0.8)],
        "Deadlock": [("State Management", 0.85)],
        
        # Testing & QA
        "Test": [("Test Planning", 0.85), ("Manual Testing", 0.8), ("Test Automation", 0.75)],
        "Crash": [("Manual Testing", 0.85), ("Defect Management", 0.8)],
        "Fail": [("Defect Management", 0.85), ("Test Planning", 0.8)],
        "Bug": [("Defect Management", 0.90), ("Test Planning", 0.8)],
        "Error": [("Defect Management", 0.85), ("API Testing", 0.7)],
        
        # Cloud/DevOps
        "Cloud": [("Cloud Architecture", 0.90), ("Cloud Deployment", 0.85)],
        "Docker": [("CI/CD Pipeline", 0.80), ("Cloud Deployment", 0.85)],
        "Kubernetes": [("Cloud Deployment", 0.90), ("Infrastructure as Code", 0.8)],
        "Deploy": [("Cloud Deployment", 0.85), ("CI/CD Pipeline", 0.8)],
        "Container": [("Cloud Deployment", 0.85), ("CI/CD Pipeline", 0.8)],
        
        # Vehicle/Protocol specific
        "Vehicle": [("Vehicle Communication", 0.90), ("Vehicle ECU Communication", 0.9)],
        "CAN": [("Vehicle ECU Communication", 0.95), ("CAN Bus Protocol", 0.95)],
        "ECU": [("Vehicle ECU Communication", 0.95), ("CAN Bus Protocol", 0.8)],
        "Protocol": [("NFC/BLE Protocol", 0.85), ("Vehicle Communication", 0.7)],
        "Bluetooth": [("Bluetooth Integration", 0.95), ("NFC/BLE Protocol", 0.85)],
        
        # System Architecture
        "System": [("System Design & Architecture", 0.85), ("Cloud Architecture", 0.7)],
        "Architecture": [("System Design & Architecture", 0.90), ("Security Architecture", 0.6)],
        "Design": [("System Design & Architecture", 0.85), ("Design Patterns", 0.8)],
        "Pattern": [("Design Patterns", 0.90)],
        "Microservices": [("Microservices", 0.95), ("API Development", 0.75)],
        "API": [("API Development", 0.90), ("API Testing", 0.85)],
    }
    
    combined_text = f"{bug_description} {bug_summary}".lower()
    found_skills = {}
    
    # Search for each tech term
    for tech_term, axiom_skills in tech_to_axiom_skills.items():
        # Create pattern to match the term as whole word
        pattern = r"\b" + re.escape(tech_term.lower()) + r"\b"
        matches = len(re.findall(pattern, combined_text, re.IGNORECASE))
        
        if matches > 0:
            # Each mention increases confidence
            confidence_boost = min(matches * 0.05, 0.2)
            
            # Map to AXIOM skills
            for axiom_skill, base_confidence in axiom_skills:
                final_confidence = min(base_confidence + confidence_boost, 0.99)
                
                if axiom_skill not in found_skills:
                    found_skills[axiom_skill] = final_confidence
                else:
                    # Keep the higher confidence
                    found_skills[axiom_skill] = max(found_skills[axiom_skill], final_confidence)
    
    # Sort by confidence descending
    return sorted(found_skills.items(), key=lambda x: x[1], reverse=True)


def find_best_assignees(
    required_skills: List[Tuple[str, float]],
    team_competencies: Dict[str, Dict[str, Any]],
    max_results: int = 3
) -> List[Dict[str, Any]]:
    """
    Find best-matched engineers for the required skills.
    
    Scoring algorithm:
    - Match required skills against competency profiles using fuzzy matching
    - Weight by confidence scores
    - Consider current capacity
    - Prefer engineers with capacity available
    """
    from difflib import SequenceMatcher
    
    candidates = []
    
    for engineer_name, profile in team_competencies.items():
        # Build engineer skills dictionary
        engineer_skills = {}
        for skill in profile.get("skills", []):
            competency_level = profile.get("competency_levels", {}).get(skill, "beginner")
            engineer_skills[skill.lower()] = {
                "original_name": skill,
                "competency_level": competency_level
            }
        
        # Calculate skill match score using fuzzy matching
        match_score = 0.0
        matched_skills = []
        
        for required_skill, confidence in required_skills:
            required_skill_lower = required_skill.lower()
            best_match_score = 0.0
            best_match_skill = None
            
            # Try to find best matching skill in engineer's profile
            for engineer_skill_lower, skill_info in engineer_skills.items():
                # Calculate similarity using sequence matching
                similarity = SequenceMatcher(None, required_skill_lower, engineer_skill_lower).ratio()
                
                if similarity > best_match_score:
                    best_match_score = similarity
                    best_match_skill = skill_info
            
            # If we found a good match (>60% similar), use it
            if best_match_skill and best_match_score > 0.6:
                # Convert competency level to numeric score
                level_scores = {
                    "expert": 1.0,
                    "advanced": 0.8,
                    "intermediate": 0.6,
                    "beginner": 0.3
                }
                competency_score = level_scores.get(best_match_skill["competency_level"], 0.3)
                
                # Final skill match = competency level * required confidence * fuzzy match
                skill_match = competency_score * confidence * best_match_score
                match_score += skill_match
                
                matched_skills.append({
                    "required_skill": required_skill,
                    "matched_skill": best_match_skill["original_name"],
                    "required_confidence": confidence,
                    "similarity": best_match_score,
                    "engineer_competency": best_match_skill["competency_level"],
                    "match_score": skill_match
                })
        
        # Penalize if at capacity
        capacity_penalty = 0.0
        current_capacity = profile.get("current_capacity_percent", 0)
        max_capacity = profile.get("max_capacity_percent", 85)
        available_capacity = max(0, max_capacity - current_capacity)
        
        if available_capacity < 20:  # Less than 20% capacity left
            capacity_penalty = 0.3
        elif available_capacity < 10:  # Critical - almost full
            capacity_penalty = 0.6
        
        final_score = max(0, match_score - capacity_penalty)
        
        candidates.append({
            "engineer_name": engineer_name,
            "role": profile.get("role", "Unknown"),
            "team": profile.get("team", "Unknown"),
            "location": profile.get("location", "Unknown"),
            "seniority": profile.get("seniority", "unknown"),
            "skill_match_score": match_score,
            "capacity_penalty": capacity_penalty,
            "final_score": final_score,
            "available_capacity_percent": available_capacity,
            "current_capacity_percent": current_capacity,
            "matched_skills": matched_skills,
            "active_tickets": len(profile.get("active_tickets", [])),
            "profile": profile
        })
    
    # Sort by final score, then by available capacity as tiebreaker
    candidates.sort(key=lambda x: (x["final_score"], x["available_capacity_percent"]), reverse=True)
    return candidates[:max_results]


def analyze_bug_for_rca(
    ticket_id: str,
    bug_summary: str,
    bug_description: str,
    error_stack: Optional[str] = None
) -> Dict[str, Any]:
    """
    Analyze bug ticket and perform Root Cause Analysis (RCA).
    
    Returns RCA report with:
    - Problem domain
    - Root causes (likely)
    - Affected components
    - Required skills for fix
    - Recommended assignees
    """
    
    # Extract required skills
    required_skills = extract_required_skills(bug_description, bug_summary)
    
    # Identify problem domain
    problem_domains = {
        "Performance": [r"\bslow\b", r"\bperformance\b", r"\blaten", r"\btimeout\b"],
        "Memory Leak": [r"\bmemory\b", r"\bleak\b", r"\bheap\b", r"\bgc\b"],
        "Crash/Exception": [r"\bcrash\b", r"\bcore\s*dump\b", r"\bsegfault\b", r"\bexcept"],
        "Race Condition": [r"\brace\s*condition\b", r"\bconcurren", r"\bthread\b", r"\bdeadlock\b"],
        "Data Corruption": [r"\bcorrupt\b", r"\binvalid\s*data\b", r"\bdata\s*loss\b"],
        "API/Integration": [r"\bapi\b", r"\bintegrat", r"\bcompat"],
        "Security": [r"\bsecurity\b", r"\bvulner", r"\binjection\b", r"\bauthent", r"\bauthoriz"],
    }
    
    combined_text = f"{bug_description} {bug_summary}".lower()
    identified_domains = {}
    
    for domain, patterns in problem_domains.items():
        for pattern in patterns:
            if re.search(pattern, combined_text):
                identified_domains[domain] = True
                break
    
    # Load team competencies
    team_competencies = _load_team_competencies()
    
    # Find best assignees
    best_assignees = find_best_assignees(required_skills, team_competencies, max_results=5)
    
    rca_report = {
        "ticket_id": ticket_id,
        "analysis_timestamp": datetime.now().isoformat(),
        "bug_summary": bug_summary,
        "required_skills": required_skills,
        "problem_domains": list(identified_domains.keys()),
        "likely_root_causes": _infer_root_causes(bug_description, identified_domains),
        "recommended_assignees": best_assignees,
        "assignment_confidence": best_assignees[0]["final_score"] if best_assignees else 0,
        "has_error_stack": error_stack is not None and len(error_stack) > 0,
        "analysis_quality": "high" if required_skills and identified_domains else "medium"
    }
    
    return rca_report


def _infer_root_causes(description: str, domains: Dict[str, bool]) -> List[str]:
    """Infer likely root causes based on problem domain."""
    causes = []
    
    if "Performance" in domains:
        causes.extend([
            "Inefficient query or algorithm",
            "Missing database index",
            "Resource contention or bottleneck",
            "Unoptimized loop or recursion"
        ])
    
    if "Memory Leak" in domains:
        causes.extend([
            "Unreleased object references",
            "Circular references preventing GC",
            "Resource not closed properly",
            "Cache growing unbounded"
        ])
    
    if "Race Condition" in domains:
        causes.extend([
            "Missing synchronization/locking",
            "Unsafetimed assumptions about order",
            "Non-atomic multi-step operations",
            "Unprotected shared state"
        ])
    
    if "Security" in domains:
        causes.extend([
            "Input validation missing",
            "SQL/code injection vulnerability",
            "Insufficient authentication/authorization",
            "Hardcoded credentials"
        ])
    
    return causes[:3]  # Return top 3


def format_rca_summary(rca_report: Dict[str, Any]) -> str:
    """Format RCA report as markdown for bug ticket comment."""
    
    summary = f"""## [RCA] Automated RCA Analysis - {rca_report['ticket_id']}

**Analysis Time:** {rca_report['analysis_timestamp']}

### Problem Domain
{', '.join(rca_report['problem_domains']) if rca_report['problem_domains'] else 'General'}

### Required Skills
"""
    
    for skill, confidence in rca_report["required_skills"]:
        summary += f"- **{skill}** (confidence: {confidence:.0%})\n"
    
    summary += f"""
### Likely Root Causes
"""
    
    for i, cause in enumerate(rca_report["likely_root_causes"], 1):
        summary += f"{i}. {cause}\n"
    
    summary += f"""
### Recommended Assignees

| Engineer | Team | Capacity Available | Match Score | Skills |
|----------|------|-------------------|-------------|--------|
"""
    
    for assignee in rca_report["recommended_assignees"][:3]:
        skills = ", ".join([s.get("matched_skill", s.get("skill", "")).title() for s in assignee["matched_skills"][:2]])
        summary += f"| {assignee['engineer_name']} | {assignee['team']} | {assignee['available_capacity_percent']}% | {assignee['final_score']:.2f} | {skills} |\n"
    
    summary += f"""
### Analysis Quality
**Confidence Level:** {rca_report['analysis_quality'].upper()}
**Assignment Confidence:** {rca_report['assignment_confidence']:.2f}

---
*Generated by AXIOM Smart Assignment Agent*
"""
    
    return summary


class HITLAssignmentAgent:
    """
    Human-In-The-Loop Assignment Agent.
    
    Performs RCA, generates summary, and prompts human for approval
    before posting to bug ticket.
    """
    
    def __init__(self, use_gemini: bool = True):
        """Initialize HITL agent."""
        self.use_gemini = use_gemini
        self.last_rca_report = None
    
    def analyze_and_present_rca(
        self,
        ticket_id: str,
        bug_summary: str,
        bug_description: str,
        error_stack: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Analyze bug and present RCA to human for review.
        
        Returns:
        - rca_report: Full RCA analysis
        - summary: Formatted markdown summary
        - next_action: What human should do
        """
        
        rca_report = analyze_bug_for_rca(
            ticket_id, bug_summary, bug_description, error_stack
        )
        self.last_rca_report = rca_report
        
        summary = format_rca_summary(rca_report)
        
        return {
            "rca_report": rca_report,
            "summary": summary,
            "next_action": "HUMAN_REVIEW_REQUIRED",
            "options": [
                "post_full_summary",
                "post_summary_only",
                "assign_to_engineer",
                "reject_analysis"
            ]
        }
    
    def post_to_bug_ticket(
        self,
        ticket_id: str,
        platform: str = "jira",
        content_type: str = "summary_only",
        assign_to: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Post RCA analysis to bug ticket.
        
        Args:
        - ticket_id: Bug ticket ID
        - platform: "jira", "github", "notion"
        - content_type: "full_rca", "summary_only"
        - assign_to: Engineer name to assign (optional)
        
        Returns:
        - success: True/False
        - message: Status message
        - ticket_url: Link to updated ticket
        """
        
        if not self.last_rca_report:
            return {"success": False, "message": "No RCA analysis available"}
        
        if content_type == "summary_only":
            content = format_rca_summary(self.last_rca_report)
        else:
            content = json.dumps(self.last_rca_report, indent=2)
        
        # Platform-specific posting logic
        if platform.lower() == "jira":
            return self._post_to_jira(ticket_id, content, assign_to)
        elif platform.lower() == "github":
            return self._post_to_github(ticket_id, content, assign_to)
        else:
            return {"success": False, "message": f"Unsupported platform: {platform}"}
    
    def _post_to_jira(
        self,
        ticket_id: str,
        content: str,
        assign_to: Optional[str] = None
    ) -> Dict[str, Any]:
        """Post comment to JIRA ticket (supports both mock and real API)."""
        # Default to top recommended engineer if not specified
        if not assign_to and self.last_rca_report:
            recommended = self.last_rca_report.get("recommended_assignees", [])
            if recommended:
                assign_to = recommended[0]["engineer_name"]
        
        logger.info(f"[HITL] Posting to JIRA {ticket_id}")
        logger.info(f"[HITL] Comment:\n{content}\n")
        logger.info(f"[HITL] Assigning to: {assign_to}")
        
        # Check if real JIRA credentials are available
        jira_url = os.getenv("JIRA_URL")
        jira_username = os.getenv("JIRA_USERNAME")
        jira_token = os.getenv("JIRA_TOKEN")
        
        if jira_url and jira_token:
            # Real JIRA API call
            try:
                # Post comment to JIRA
                comment_response = requests.post(
                    f"{jira_url}/rest/api/3/issue/{ticket_id}/comment",
                    json={
                        "body": {
                            "type": "doc",
                            "version": 1,
                            "content": [
                                {
                                    "type": "paragraph",
                                    "content": [
                                        {
                                            "type": "text",
                                            "text": content
                                        }
                                    ]
                                }
                            ]
                        }
                    },
                    headers={
                        "Authorization": f"Bearer {jira_token}",
                        "Content-Type": "application/json"
                    },
                    timeout=10
                )
                
                if comment_response.status_code not in [200, 201]:
                    logger.error(f"[JIRA] Comment posting failed: {comment_response.status_code}")
                    logger.error(f"[JIRA] Response: {comment_response.text}")
                
                # Assign ticket if engineer specified
                assigned_success = False
                if assign_to:
                    assign_response = requests.put(
                        f"{jira_url}/rest/api/3/issue/{ticket_id}",
                        json={
                            "fields": {
                                "assignee": {"name": assign_to}
                            }
                        },
                        headers={
                            "Authorization": f"Bearer {jira_token}",
                            "Content-Type": "application/json"
                        },
                        timeout=10
                    )
                    assigned_success = assign_response.status_code in [200, 204]
                    
                    if not assigned_success:
                        logger.error(f"[JIRA] Assignment failed: {assign_response.status_code}")
                        logger.error(f"[JIRA] Response: {assign_response.text}")
                
                return {
                    "success": comment_response.status_code in [200, 201],
                    "message": f"Posted RCA to JIRA {ticket_id}",
                    "ticket_url": f"{jira_url}/browse/{ticket_id}",
                    "assigned_engineer": assign_to if assigned_success else None,
                    "assignment_rank": 0,
                    "api_call": "REAL_JIRA_API"
                }
            
            except Exception as e:
                logger.error(f"[JIRA] API error: {str(e)}")
                return {
                    "success": False,
                    "message": f"Failed to post to JIRA: {str(e)}",
                    "ticket_url": f"{jira_url}/browse/{ticket_id}",
                    "assigned_engineer": None,
                    "api_call": "REAL_JIRA_API_FAILED"
                }
        
        # Fallback to mock posting
        return {
            "success": True,
            "message": f"[MOCK] Posted to JIRA {ticket_id}",
            "ticket_url": f"https://jira.example.com/browse/{ticket_id}",
            "assigned_engineer": assign_to,
            "assignment_rank": None,
            "api_call": "MOCK_JIRA"
        }
    
    def _post_to_github(
        self,
        ticket_id: str,
        content: str,
        assign_to: Optional[str] = None
    ) -> Dict[str, Any]:
        """Post comment to GitHub issue (supports both mock and real API)."""
        # Default to top recommended engineer if not specified
        if not assign_to and self.last_rca_report:
            recommended = self.last_rca_report.get("recommended_assignees", [])
            if recommended:
                assign_to = recommended[0]["engineer_name"]
        
        logger.info(f"[HITL] Posting to GitHub #{ticket_id}")
        logger.info(f"[HITL] Comment:\n{content}\n")
        logger.info(f"[HITL] Assigning to: {assign_to}")
        
        # Check if real GitHub credentials are available
        github_token = os.getenv("GITHUB_TOKEN", "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")
        github_repo = os.getenv("GITHUB_REPO", "JyothiLakshmikanth/EKey2W")  # Format: owner/repo
        
        if github_token and github_repo:
            # Real GitHub API call
            try:
                # Post comment to GitHub issue
                comment_response = requests.post(
                    f"https://api.github.com/repos/{github_repo}/issues/{ticket_id}/comments",
                    json={"body": content},
                    headers={
                        "Authorization": f"Bearer {github_token}",
                        "Accept": "application/vnd.github.v3+json",
                        "Content-Type": "application/json"
                    },
                    timeout=10
                )
                
                if comment_response.status_code not in [200, 201]:
                    logger.error(f"[GitHub] Comment posting failed: {comment_response.status_code}")
                    logger.error(f"[GitHub] Response: {comment_response.text}")
                
                # Assign ticket if engineer specified
                assigned_success = False
                if assign_to:
                    assign_response = requests.patch(
                        f"https://api.github.com/repos/{github_repo}/issues/{ticket_id}",
                        json={"assignees": [assign_to]},
                        headers={
                            "Authorization": f"Bearer {github_token}",
                            "Accept": "application/vnd.github.v3+json",
                            "Content-Type": "application/json"
                        },
                        timeout=10
                    )
                    assigned_success = assign_response.status_code in [200, 201]
                    
                    if not assigned_success:
                        logger.error(f"[GitHub] Assignment failed: {assign_response.status_code}")
                        logger.error(f"[GitHub] Response: {assign_response.text}")
                
                return {
                    "success": comment_response.status_code in [200, 201],
                    "message": f"Posted RCA to GitHub #{ticket_id}",
                    "ticket_url": f"https://github.com/{github_repo}/issues/{ticket_id}",
                    "assigned_engineer": assign_to if assigned_success else None,
                    "assignment_rank": 0,
                    "api_call": "REAL_GITHUB_API"
                }
            
            except Exception as e:
                logger.error(f"[GitHub] API error: {str(e)}")
                return {
                    "success": False,
                    "message": f"Failed to post to GitHub: {str(e)}",
                    "ticket_url": f"https://github.com/{github_repo}/issues/{ticket_id}",
                    "assigned_engineer": None,
                    "api_call": "REAL_GITHUB_API_FAILED"
                }
        
        # Fallback to mock posting
        return {
            "success": True,
            "message": f"[MOCK] Posted to GitHub #{ticket_id}",
            "ticket_url": f"https://github.com/example/repo/issues/{ticket_id}",
            "assigned_engineer": assign_to,
            "assignment_rank": None,
            "api_call": "MOCK_GITHUB"
        }


# Convenience functions for resource_agent integration
def smart_assign_bug(
    ticket_id: str,
    bug_summary: str,
    bug_description: str,
    error_stack: Optional[str] = None
) -> Dict[str, Any]:
    """
    Quick interface for resource_agent to perform smart bug assignment.
    """
    return analyze_bug_for_rca(ticket_id, bug_summary, bug_description, error_stack)


def get_hitl_agent() -> HITLAssignmentAgent:
    """Get initialized HITL agent instance."""
    return HITLAssignmentAgent(use_gemini=True)
