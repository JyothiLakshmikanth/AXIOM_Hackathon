"""
Smart Bug Assignment & RCA Analysis Page
==========================================

Interactive page for:
1. Analyzing bugs and generating RCA
2. Displaying engineer recommendations
3. Selecting and posting assignments to JIRA
4. Providing real-time feedback

Run with: streamlit run streamlit_app.py
Navigate to "Smart Assignment" in the sidebar
"""

import streamlit as st
import sys
from pathlib import Path

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from agents.resource_agent import resource_agent


def render_rca_analysis_interface():
    """Main interface for bug analysis and assignment."""
    
    st.title("🔍 Smart Bug Assignment & RCA")
    st.markdown("Automatic Root Cause Analysis + Intelligent Engineer Selection")
    
    # Input form
    with st.form("bug_analysis_form"):
        col1, col2 = st.columns([1, 1])
        
        with col1:
            ticket_id = st.text_input(
                "Ticket ID",
                value="BUG-001",
                help="JIRA/GitHub ticket identifier"
            )
            
            bug_summary = st.text_input(
                "Bug Summary",
                value="PostgreSQL queries timing out on large datasets",
                help="One-line bug description"
            )
        
        with col2:
            platform = st.selectbox(
                "Target Platform",
                options=["jira", "github", "notion"],
                help="Where to post the assignment"
            )
            
            assign_to_rank = st.selectbox(
                "Assignment Preference",
                options=["#1 (Top Match)", "#2 (Second)", "#3 (Third)"],
                help="Which recommendation to use"
            )
        
        bug_description = st.text_area(
            "Bug Description",
            value="""Orders table has 2.3M rows. Simple WHERE queries on unindexed columns take 45+ seconds.
API endpoints timing out (30s limit). Performance degrades as table grows.
Recent deployments didn't change query logic.""",
            height=120,
            help="Detailed context and observations"
        )
        
        error_stack = st.text_area(
            "Error Stack Trace (Optional)",
            value="",
            height=80,
            help="Full error output or stack trace"
        )
        
        col_button1, col_button2 = st.columns([1, 1])
        
        with col_button1:
            analyze_button = st.form_submit_button(
                "🚀 Analyze Bug",
                use_container_width=True,
                type="primary"
            )
        
        with col_button2:
            st.form_submit_button(
                "Clear Form",
                use_container_width=True,
            )
    
    if analyze_button:
        with st.spinner("🤖 Analyzing bug and generating RCA..."):
            # Perform RCA analysis via resource agent
            result = resource_agent.analyze_and_assign_bug(
                ticket_id=ticket_id,
                bug_summary=bug_summary,
                bug_description=bug_description,
                error_stack=error_stack if error_stack.strip() else None
            )
        
        if result.get("success"):
            rca_report = result["rca_report"]
            
            # Store in session for later use
            st.session_state["analysis_result"] = result
            st.session_state["ticket_id"] = ticket_id
            st.session_state["platform"] = platform
            st.session_state["assign_rank"] = 0 if assign_to_rank == "#1 (Top Match)" else (1 if assign_to_rank == "#2 (Second)" else 2)
            
            # Display RCA Results
            st.divider()
            st.subheader("📊 RCA Analysis Results")
            
            # Problem domains
            col1, col2 = st.columns(2)
            
            with col1:
                st.markdown("**Problem Domains Identified:**")
                if rca_report.get("problem_domains"):
                    for domain in rca_report["problem_domains"]:
                        st.info(f"🎯 {domain}")
                else:
                    st.warning("No specific domains identified")
            
            with col2:
                st.markdown("**Root Causes (Suspected):**")
                causes = rca_report.get("likely_root_causes", [])
                for i, cause in enumerate(causes[:3], 1):
                    st.markdown(f"{i}. {cause}")
            
            # Required skills
            st.markdown("---")
            st.markdown("**Skills Required to Fix:**")
            skills = rca_report.get("required_skills", [])
            
            skill_cols = st.columns(min(5, len(skills)))
            for idx, (skill, conf) in enumerate(skills[:5]):
                with skill_cols[idx]:
                    st.metric(
                        skill,
                        f"{conf:.0%}",
                        delta="High Priority" if conf > 0.85 else "Standard"
                    )
            
            # Recommended engineers
            st.markdown("---")
            st.subheader("👥 Recommended Engineers")
            
            recommended = rca_report.get("recommended_assignees", [])
            
            tabs = st.tabs([f"#{i+1} - {eng['engineer_name']}" for i, eng in enumerate(recommended[:3])])
            
            for tab_idx, tab in enumerate(tabs):
                with tab:
                    engineer = recommended[tab_idx]
                    
                    col_main, col_side = st.columns([2, 1])
                    
                    with col_main:
                        st.markdown(f"### {engineer['engineer_name']}")
                        st.markdown(f"**Role:** {engineer.get('role', 'Unknown')}")
                        st.markdown(f"**Team:** {engineer.get('team', 'Unknown')}")
                        st.markdown(f"**Location:** {engineer.get('location', 'Unknown')}")
                        
                        st.markdown("**Matched Skills:**")
                        matched = engineer.get('matched_skills', [])
                        for skill in matched[:5]:
                            competency = skill.get('engineer_competency', 'unknown')
                            emoji = "⭐" if competency == "expert" else ("📌" if competency == "advanced" else "📍")
                            st.markdown(f"{emoji} **{skill.get('matched_skill', '')}** ({competency})")
                    
                    with col_side:
                        st.metric(
                            "Match Score",
                            f"{engineer['final_score']:.2f}",
                            delta=f"{engineer['available_capacity_percent']:.0f}% capacity"
                        )
                        
                        if engineer['available_capacity_percent'] > 30:
                            st.success("✅ Good capacity")
                        elif engineer['available_capacity_percent'] > 10:
                            st.warning("⚠️ Limited capacity")
                        else:
                            st.error("❌ Over capacity")
            
            # Assignment section
            st.markdown("---")
            st.subheader("📤 Post Assignment")
            
            col_assign1, col_assign2 = st.columns([2, 1])
            
            with col_assign1:
                selected_rank = st.radio(
                    "Select engineer to assign:",
                    options=[f"#{i+1} - {eng['engineer_name']} (Score: {eng['final_score']:.2f})" 
                            for i, eng in enumerate(recommended[:3])],
                    index=st.session_state.get("assign_rank", 0),
                    horizontal=False
                )
                
                assign_rank = int(selected_rank.split("-")[0].replace("#", "")) - 1
            
            with col_assign2:
                if st.button("✅ Post Assignment", use_container_width=True, type="primary"):
                    with st.spinner(f"📨 Posting to {platform.upper()}..."):
                        post_result = resource_agent.post_rca_to_ticket(
                            ticket_id=ticket_id,
                            rca_report=rca_report,
                            platform=platform,
                            assign_rank=assign_rank
                        )
                    
                    if post_result.get("success"):
                        st.success(f"""
                        ✅ **Successfully Posted!**
                        
                        - **Ticket:** {post_result.get('ticket_url')}
                        - **Assigned to:** {post_result.get('assigned_engineer')}
                        - **Rank:** #{post_result.get('assignment_rank')}
                        - **Platform:** {platform.upper()}
                        """)
                        
                        st.session_state["last_assignment"] = {
                            "ticket_id": ticket_id,
                            "engineer": post_result.get("assigned_engineer"),
                            "rank": post_result.get("assignment_rank")
                        }
                    else:
                        st.error(f"❌ Failed: {post_result.get('error', 'Unknown error')}")
        
        else:
            st.error(f"❌ Analysis failed: {result.get('error', 'Unknown error')}")


def render_feedback_section():
    """Feedback section for continuous improvement."""
    
    if "last_assignment" in st.session_state:
        st.divider()
        st.subheader("📝 Assignment Feedback")
        st.markdown("Help improve the system with your feedback")
        
        col1, col2 = st.columns([1, 2])
        
        with col1:
            accuracy = st.radio(
                "Was the assignment accurate?",
                options=[
                    "✅ Yes, excellent match",
                    "⚠️ Partially correct",
                    "❌ Wrong choice"
                ],
                label_visibility="collapsed"
            )
        
        with col2:
            notes = st.text_area(
                "Additional notes (optional)",
                placeholder="Why was this assignment good/bad? Any suggestions?",
                height=80
            )
        
        if st.button("💾 Save Feedback", use_container_width=True):
            feedback = {
                "ticket_id": st.session_state["last_assignment"]["ticket_id"],
                "assigned_engineer": st.session_state["last_assignment"]["engineer"],
                "accuracy": accuracy,
                "notes": notes
            }
            st.success("✅ Feedback saved for continuous improvement")
            st.json(feedback)


def main():
    """Main page layout."""
    
    st.set_page_config(
        page_title="Smart Assignment",
        page_icon="🔍",
        layout="wide"
    )
    
    render_rca_analysis_interface()
    render_feedback_section()
    
    # Help section
    with st.expander("❓ How it works"):
        st.markdown("""
        ### Smart Assignment Process
        
        1. **Input**: Provide bug details (title, description, stack trace)
        2. **Analyze**: System extracts required skills and generates RCA
        3. **Score**: Matches skills against real team competencies
        4. **Recommend**: Considers capacity and recommends engineers
        5. **Assign**: Posts RCA and assignment to JIRA/GitHub
        6. **Feedback**: System learns from human feedback
        
        ### Scoring Formula
        ```
        score = (skill_match × competency_level × fuzzy_match) - capacity_penalty
        ```
        
        Engineers with more relevant skills and available capacity rank higher.
        """)


if __name__ == "__main__":
    main()
