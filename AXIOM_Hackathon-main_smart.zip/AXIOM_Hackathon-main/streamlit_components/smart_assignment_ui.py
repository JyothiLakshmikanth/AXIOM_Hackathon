"""
Streamlit UI Component for Smart Bug Assignment
================================================

Interactive UI for:
1. Analyzing bugs and generating RCA
2. Displaying engineer recommendations
3. Selecting and posting assignments to JIRA
4. Providing real-time feedback
"""

import streamlit as st
import json
from typing import Dict, Any, Optional, List
from agents.resource_agent import resource_agent
from agents.tools.smart_assignment import get_hitl_agent


def render_rca_analysis_interface():
    """Main interface for bug analysis and assignment."""
    
    st.title("🔍 Smart Bug Assignment & RCA Analysis")
    st.markdown("Automatic Root Cause Analysis + Intelligent Engineer Recommendation")
    
    # Create two columns
    col_input, col_results = st.columns([1, 1.5], gap="large")
    
    with col_input:
        st.subheader("📋 Bug Report Details")
        
        with st.form("bug_analysis_form"):
            ticket_id = st.text_input(
                "Ticket ID",
                value="BUG-001",
                help="JIRA/GitHub ticket identifier"
            )
            
            bug_summary = st.text_input(
                "Bug Summary",
                value="PostgreSQL queries timing out on large datasets",
                help="One-line description of the bug"
            )
            
            bug_description = st.text_area(
                "Bug Description",
                value="""Orders table has 2.3M rows. Simple WHERE queries on unindexed columns take 45+ seconds.
API endpoints timing out (30s limit). No indexes on customer_id or date columns.
Performance degrades as table grows.""",
                height=150,
                help="Detailed bug description with context"
            )
            
            error_stack = st.text_area(
                "Error Stack (Optional)",
                value="",
                height=100,
                help="Stack trace or error output"
            )
            
            submit_button = st.form_submit_button(
                "🚀 Analyze Bug",
                use_container_width=True
            )
    
    if submit_button:
        with st.spinner("🤖 Analyzing bug and generating RCA..."):
            # Perform RCA analysis
            result = resource_agent.analyze_and_assign_bug(
                ticket_id=ticket_id,
                bug_summary=bug_summary,
                bug_description=bug_description,
                error_stack=error_stack if error_stack.strip() else None
            )
        
        if result.get("success"):
            rca_report = result["rca_report"]
            
            # Store in session state for later use
            st.session_state["last_rca_report"] = rca_report
            st.session_state["ticket_id"] = ticket_id
            st.session_state["rca_summary"] = result["rca_summary"]
            
            with col_results:
                st.subheader("📊 RCA Analysis Results")
                
                # Display problem domains
                if rca_report.get("problem_domains"):
                    st.markdown("**Problem Domains Identified:**")
                    domains = ", ".join(rca_report["problem_domains"])
                    st.info(f"🎯 {domains}")
                
                # Display required skills
                st.markdown("**Required Skills:**")
                required_skills = rca_report.get("required_skills", [])
                skills_df = {
                    "Skill": [s[0] for s in required_skills[:5]],
                    "Confidence": [f"{s[1]:.0%}" for s in required_skills[:5]]
                }
                st.dataframe(skills_df, use_container_width=True)
                
                # Display root causes
                st.markdown("**Likely Root Causes:**")
                for i, cause in enumerate(rca_report.get("likely_root_causes", [])[:3], 1):
                    st.markdown(f"{i}. {cause}")
                
                # Display recommended engineers
                st.markdown("**Recommended Engineers:**")
                recommended = rca_report.get("recommended_assignees", [])
                
                for rank, engineer in enumerate(recommended[:3], 1):
                    with st.container(border=rank == 1):
                        col_rank, col_info = st.columns([0.2, 1])
                        
                        with col_rank:
                            st.metric(f"#{rank}", f"{engineer['final_score']:.2f}")
                        
                        with col_info:
                            st.markdown(f"**{engineer['engineer_name']}**")
                            st.caption(f"📍 {engineer.get('location', 'Unknown')} | "
                                     f"{engineer.get('available_capacity_percent', 0):.0f}% capacity free")
                            
                            matched = engineer.get('matched_skills', [])
                            if matched:
                                skills_text = ", ".join([
                                    m.get('matched_skill', m.get('skill', ''))
                                    for m in matched[:2]
                                ])
                                st.caption(f"💡 {skills_text}")
        else:
            st.error(f"❌ Analysis failed: {result.get('error', 'Unknown error')}")


def render_assignment_interface():
    """Interface for selecting and posting assignments."""
    
    st.divider()
    st.subheader("📤 Post Assignment to Ticket")
    
    if "last_rca_report" not in st.session_state:
        st.info("👈 Analyze a bug first using the form above")
        return
    
    rca_report = st.session_state["last_rca_report"]
    ticket_id = st.session_state["ticket_id"]
    recommended = rca_report.get("recommended_assignees", [])
    
    col1, col2, col3 = st.columns([1, 1, 1])
    
    with col1:
        st.markdown("**Select Engineer:**")
        engineer_options = {
            f"#{i+1} - {eng['engineer_name']} ({eng['final_score']:.2f})": i
            for i, eng in enumerate(recommended[:3])
        }
        
        selected_label = st.radio(
            "Choose assignment",
            options=engineer_options.keys(),
            label_visibility="collapsed"
        )
        assign_rank = engineer_options[selected_label]
    
    with col2:
        st.markdown("**Target Platform:**")
        platform = st.selectbox(
            "Choose platform",
            options=["jira", "github"],
            label_visibility="collapsed"
        )
    
    with col3:
        st.markdown("**Content Type:**")
        content_type = st.selectbox(
            "What to post",
            options=["summary_only", "full_rca"],
            label_visibility="collapsed"
        )
    
    # Display selected engineer details
    selected_engineer = recommended[assign_rank]
    st.markdown("---")
    st.markdown("**Selected Assignment:**")
    col_detail1, col_detail2 = st.columns(2)
    
    with col_detail1:
        st.metric(
            "Engineer",
            selected_engineer['engineer_name'],
            f"Score: {selected_engineer['final_score']:.2f}"
        )
    
    with col_detail2:
        st.metric(
            "Availability",
            f"{selected_engineer['available_capacity_percent']:.0f}%",
            "capacity free"
        )
    
    # Show matched skills
    matched = selected_engineer.get('matched_skills', [])
    if matched:
        st.markdown("**Matched Skills:**")
        for skill in matched[:3]:
            st.caption(f"✓ {skill.get('matched_skill', '')} "
                      f"({skill.get('engineer_competency', 'unknown')})")
    
    # Post button
    if st.button("✅ Post Assignment & RCA to Ticket", use_container_width=True, type="primary"):
        with st.spinner(f"📨 Posting to {platform.upper()}..."):
            result = resource_agent.post_rca_to_ticket(
                ticket_id=ticket_id,
                rca_report=rca_report,
                platform=platform,
                assign_rank=assign_rank
            )
        
        if result.get("success"):
            st.success(f"""
            ✅ Successfully Posted!
            
            **Ticket:** {result.get('ticket_url')}
            **Assigned to:** {result.get('assigned_engineer')}
            **Rank:** #{result.get('assignment_rank')}
            """)
            st.session_state["last_assignment"] = result
        else:
            st.error(f"❌ Failed to post: {result.get('error', 'Unknown error')}")


def render_feedback_section():
    """Feedback section for human review."""
    
    st.divider()
    st.subheader("📝 Assignment Feedback")
    
    if "last_assignment" not in st.session_state:
        return
    
    col_feedback1, col_feedback2 = st.columns([1, 1])
    
    with col_feedback1:
        accuracy = st.radio(
            "Was the assignment accurate?",
            options=["✅ Yes, excellent match", "⚠️ Partially correct", "❌ Wrong choice"],
            label_visibility="collapsed"
        )
    
    with col_feedback2:
        notes = st.text_area(
            "Additional notes (optional)",
            placeholder="Feedback for system improvement...",
            height=80
        )
    
    if st.button("💾 Save Feedback"):
        feedback = {
            "ticket_id": st.session_state.get("ticket_id"),
            "assigned_engineer": st.session_state.get("last_assignment", {}).get("assigned_engineer"),
            "accuracy": accuracy,
            "notes": notes,
            "timestamp": str(pd.Timestamp.now()) if 'pd' in dir() else "unknown"
        }
        st.success("✅ Feedback saved for model improvement")


def main():
    """Main app layout."""
    
    # Page config
    st.set_page_config(
        page_title="Smart Bug Assignment",
        page_icon="🔍",
        layout="wide",
        initial_sidebar_state="collapsed"
    )
    
    # Sidebar
    with st.sidebar:
        st.markdown("## 🔧 Configuration")
        show_debug = st.checkbox("Show debug info")
        
        if show_debug and "last_rca_report" in st.session_state:
            with st.expander("Raw RCA Report"):
                st.json(st.session_state["last_rca_report"])
    
    # Main interface
    render_rca_analysis_interface()
    render_assignment_interface()
    render_feedback_section()
    
    # Footer
    st.divider()
    st.markdown("""
    ---
    **Smart Assignment System** | Integrated with Resource Agent  
    Powered by skill matching + capacity planning
    """)


if __name__ == "__main__":
    main()
