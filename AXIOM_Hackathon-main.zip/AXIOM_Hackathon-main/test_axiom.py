#!/usr/bin/env python3
"""
Quick AXIOM Functionality Test Script
Tests routing, master selection, and basic query handling
"""

import sys
import json
import logging
from typing import Dict, Any

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s"
)
logger = logging.getLogger("axiom.test")

# Import AXIOM components
try:
    from orchestrator.router import analyze_intent
    from orchestrator.state import AxiomState
    logger.info("✅ Successfully imported AXIOM components")
except ImportError as e:
    logger.error(f"❌ Failed to import AXIOM: {e}")
    sys.exit(1)


def test_query(query: str, test_name: str) -> Dict[str, Any]:
    """Test a single query through the router"""
    print("\n" + "="*80)
    print(f"TEST: {test_name}")
    print(f"QUERY: {query}")
    print("="*80)
    
    try:
        result = analyze_intent(query)
        
        print(f"\n✅ Router Result:")
        print(f"   Clarification Needed: {result.get('clarification_needed', False)}")
        print(f"   Target Master: {result.get('target_master', 'N/A')}")
        print(f"   Target Capability: {result.get('target_capability', 'N/A')}")
        print(f"   Confidence Score: {result.get('confidence_score', 0):.2f}")
        print(f"   Reasoning: {result.get('reasoning_summary', 'N/A')}")
        
        if result.get('clarification_needed'):
            print(f"\n❓ Clarification Questions:")
            for i, q in enumerate(result.get('clarification_questions', []), 1):
                print(f"   {i}. {q}")
        
        return result
    except Exception as e:
        print(f"❌ Error: {e}")
        import traceback
        traceback.print_exc()
        return {"error": str(e)}


def main():
    """Run test suite"""
    print("\n")
    print("╔" + "="*78 + "╗")
    print("║" + " "*78 + "║")
    print("║" + "  AXIOM Multi-Agent Intelligence System - Test Suite".center(78) + "║")
    print("║" + "  Testing Router & Master Selection Logic".center(78) + "║")
    print("║" + " "*78 + "║")
    print("╚" + "="*78 + "╝")
    
    # Test Suite
    tests = [
        (
            "What is the blast radius and defect triage for GH-ISSUE-107?",
            "AXIOM-PM: Defect Triage Query"
        ),
        (
            "Perform deep code RCA and generate surgical patch for proximity_controller.py",
            "AXIOM-ENG: Code RCA & Patch Generation"
        ),
        (
            "Sprint 4 is slipping by 18 story points, how should we replan?",
            "AXIOM-PM: Sprint Replanning Query"
        ),
        (
            "What test coverage gaps exist for the BLE unlock feature?",
            "AXIOM-ENG: Test Coverage Analysis"
        ),
        (
            "Base variant fails passive unlock when BLE RSSI drops below threshold",
            "AXIOM-PM: Requirement Impact Analysis"
        ),
        (
            "fix something",
            "AXIOM: Ambiguous Query (Should Request Clarification)"
        ),
        (
            "hi",
            "AXIOM: Vague Query (Should Request Clarification)"
        ),
        (
            "Perform 8D problem solving for the proximity_controller hysteresis bug",
            "AXIOM-ENG: Eight Disciplines Analysis"
        ),
        (
            "Generate pytest test cases for edge cases in unlock logic",
            "AXIOM-ENG: Test Generation"
        ),
        (
            "What is the project health scorecard and delivery forecast?",
            "AXIOM-PM: Project Health Query"
        ),
    ]
    
    results = []
    passed = 0
    failed = 0
    
    for query, test_name in tests:
        result = test_query(query, test_name)
        results.append({
            "test": test_name,
            "query": query,
            "result": result
        })
        
        if "error" not in result:
            passed += 1
        else:
            failed += 1
    
    # Summary Report
    print("\n\n" + "="*80)
    print("TEST SUMMARY REPORT")
    print("="*80)
    
    print(f"\n✅ Passed: {passed}")
    print(f"❌ Failed: {failed}")
    print(f"📊 Total: {len(tests)}")
    print(f"✨ Success Rate: {(passed/len(tests)*100):.1f}%")
    
    # Master Distribution
    print("\n\nROUTING DISTRIBUTION:")
    axiom_pm_count = sum(1 for r in results if r['result'].get('target_master') == 'AXIOM-PM')
    axiom_eng_count = sum(1 for r in results if r['result'].get('target_master') == 'AXIOM-ENG')
    clarification_count = sum(1 for r in results if r['result'].get('clarification_needed'))
    
    print(f"   🛡️  AXIOM-PM (Project Management): {axiom_pm_count}")
    print(f"   ⚡ AXIOM-ENG (Engineering): {axiom_eng_count}")
    print(f"   ❓ Clarification Required: {clarification_count}")
    
    # Capability Distribution
    print("\n\nCAPABILITY DISTRIBUTION:")
    capabilities = {}
    for r in results:
        cap = r['result'].get('target_capability', 'N/A')
        if cap != 'N/A':
            capabilities[cap] = capabilities.get(cap, 0) + 1
    
    for cap, count in sorted(capabilities.items(), key=lambda x: x[1], reverse=True):
        print(f"   • {cap}: {count}")
    
    print("\n" + "="*80)
    print("✅ TEST SUITE COMPLETE")
    print("="*80 + "\n")
    
    return 0 if failed == 0 else 1


if __name__ == "__main__":
    exit_code = main()
    sys.exit(exit_code)
